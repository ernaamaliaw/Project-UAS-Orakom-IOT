Arduino_Makefile_master
=======================

Use make on macos Darwin or linux instead of arduino IDE.

```
NOTE:
  If your sketch (.ino) does not compile because YOU did not include Arduino.h or 
  Wprogram.h then YOU need to fix YOUR code.
  YOU need to also properly do all function prototypes as well.
  Avoid problems! Do your code the proper way from the start.

Features:
  Supports standard avr Arduino boards
  Supports the Teensy development boards from pjrc.com

NEW:
  Faster compiles.
  Libraries are now each an archive, seperately.
```
