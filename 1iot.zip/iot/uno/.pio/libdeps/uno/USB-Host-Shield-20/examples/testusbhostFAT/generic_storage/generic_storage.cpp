/* Yup, just a bunch of includes. */
#include "PCpartition/PCPartition.cpp"
#include"FAT/FAT.cpp"
